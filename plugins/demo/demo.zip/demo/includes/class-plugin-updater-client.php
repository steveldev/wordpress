<?php
/**
 * Author: Steve LERAT (contact@reseau-net.fr)
 * Author URI: https://reseau-net.fr
 */

if ( ! defined( 'ABSPATH' ) )  die();

WPPluginManagerClient::getInstance();

class WPPluginManagerClient {

	static $instance = false;
	
	public function __construct() {		
	
		$this->plugin_slug = basename( dirname( __DIR__ ) );
		$this->plugin_file = $this->plugin_slug .'/'. $this->plugin_slug.'.php';
		$this->plugin_dir  = dirname( __DIR__ );
		$this->plugin_update_url = site_url() .'/wp-json/api/wp-plugins';

		$this->plugin_data_updated = false;
		
		add_action('admin_enqueue_scripts', [$this, 'admin_enqueue_scripts']);

		add_filter( 'plugins_api', [$this, 'plugins_api'], 20, 3 );
		
		add_filter( 'site_transient_update_plugins', [$this, 'upload_plugin'] );
		add_filter( 'transient_update_plugins',  [$this, 'upload_plugin']);
		
		add_action( 'upgrader_process_complete', array( $this, 'purge_transient' ), 10, 2 );

		add_action( 'in_plugin_update_message-'.$this->plugin_file, [$this, 'plugin_update_message'], 10, 2 );
	}

    /**
	 * If an instance exists, this returns it.  If not, it creates one and retuns it.
	 *
	 * @return self
	 */
	public static function getInstance() {
		if ( !self::$instance )
			self::$instance = new self;
		return self::$instance;
	}

	/**
	 * Assets
	 */
	public function admin_enqueue_scripts() {
		// markdown converter : https://github.com/showdownjs/showdown
		wp_enqueue_script('markdown-js', 'https://unpkg.com/showdown/dist/showdown.min.js', [], false, true);
		wp_enqueue_script('admin-js', dirname( plugin_dir_url(__FILE__) ) .'/src/admin.js',[],false,true);
	}

	/**
	 * Get plugin data
	 */
	public function get_plugin_data() {
		
		// get plugin transient
		$plugin_data = get_transient( $this->plugin_slug );

		if( empty( $plugin_data) || $this->plugin_data_updated == false) {
			// get plugin data form api
			$response = wp_remote_get($this->plugin_update_url);
			$plugin_data = wp_remote_retrieve_body( $response );
			$plugin_data = json_decode( $plugin_data );


			// test plugin data
			if(
				is_wp_error( $plugin_data )
			//	|| 200 !== wp_remote_retrieve_response_code( $plugin_data )
				|| empty(  $plugin_data  )
			) {
				return false;
			}

			// set plugin transient
			set_transient( $this->plugin_slug, $plugin_data, DAY_IN_SECONDS );


			$this->plugin_data_updated = true;
		}


		
		return $plugin_data;
	}


	/**
	 * Set plugin informations 
	 *
	 * @return object
	 */
	public function plugins_api(  $res, $action, $args ) {

		if( 'plugin_information' !== $action ) {
			return $res;
		}
		if( $this->plugin_slug != $args->slug ) {
			return $res;
		}

		//	$plugin_data = $this->get_plugin_data();

		$section_before = '<div class="markdown">';
		$section_after = '</div>';

		$description 	= file_get_contents( $this->plugin_dir . '/README.md');
		$installation 	= file_get_contents( $this->plugin_dir . '/README.md');
		$changelog 		= file_get_contents( $this->plugin_dir . '/CHANGELOG.md');
		$documentation 	= file_get_contents( $this->plugin_dir . '/README.md');
		$licence 		= file_get_contents( $this->plugin_dir . '/Licence.txt');
		
		$plugin_data = $this->get_plugin_data();		
		$plugin_data->sections = (array) $plugin_data->sections;
		$plugin_data->banners  = (array) $plugin_data->banners;
		return $plugin_data;
		
		return (object)  array(
			'name'			=> $this->plugin_slug,
			'slug'         	=> $this->plugin_slug, // Whatever you want, as long as it's not on WordPress.org
			'new_version'  	=> '2.0', // The newest version
			'url'          	=> 'https://github.com/wp-remote-sample-plugin', // Informational
			'package'      	=> 'https://github.com/wp-remote-sample-plugin/archive/0.2.zip', // Where WordPress should pull the ZIP from.
			"download_url" 	=> "https://rudrastyh.com/wp-content/uploads/updater/misha-update-checker.zip",
			"author" 		=> "<a href='https://reseau-net.fr'>Steve LERAT</a>",
			"author_profile"=> "https://reseau-net.fr",
			"version" 		=> "2.0",
			"requires" 		=> "5.9",
			"tested" 		=> "5.9.3",
			"requires_php" 	=> "7.4",
			"last_updated" 	=> "2022-05-17 08:00:00",
			'sections' 		=> array(
				"description" => $section_before. $description . $section_after,
				"installation" => "Click the activate button and that's it.",
				"changelog" => $section_before. $changelog . $section_after,
				"documentation" => $section_before. $documentation . $section_after,
				"licence" => $section_before. $licence . $section_after,
			),
			"banners" 		=> array(
				"low" => site_url().'/wp-content/plugins/levraimarche/assets/banners/banner640x427.jpg', // 772*250
				"high" => site_url().'/wp-content/plugins/levraimarche/assets/banners/banner640x427.jpg', //1544*500
			),
			
		);
		
	}

	/**
	 * Check for plugins updates
	 *
	 */
	public function upload_plugin( $transient_update_plugins ) {

		if ( empty($transient_update_plugins->checked ) ) {
			return $transient_update_plugins;
		}

		if ( ! is_object( $transient_update_plugins ) )
				return $transient_update_plugins;

		if ( ! isset( $transient_update_plugins->response ) || ! is_array( $transient_update_plugins->response ) )
			$transient_update_plugins->response = array();

				
		$plugin_data = $this->get_plugin_data();


		if (empty( $plugin_data )  ) return $transient_update_plugins;

		// convert object value to array
		$plugin_data->sections = (array) $plugin_data->sections;
		$plugin_data->banners  = (array) $plugin_data->banners;
		$plugin_data = [$this->plugin_file => $plugin_data];

		// merge plugins updates
		$transient_update_plugins->response= array_merge($transient_update_plugins->response, $plugin_data);

		return $transient_update_plugins;
	}

	/**
	 * Plugin Update Notice
	 */
	public function plugin_update_message( $plugin_data, $new_data ) {
		return;
		if ( isset( $plugin_data['update'] ) && $plugin_data['update'] && isset( $new_data->upgrade_notice ) ) {
			printf(
				'<div class="upgrade_notice"><p><strong>%s</strong>: %s</p></div>',
				$new_data -> new_version,
				wpautop( $new_data -> upgrade_notice )
			);
		}
	}


	/**
	 * Delete plugin update transient
	 */
	public function purge_transient(){
		delete_transient($this->plugin_slug);
	}
}